EARNOVA static site for Cloudflare Pages Direct Upload.
